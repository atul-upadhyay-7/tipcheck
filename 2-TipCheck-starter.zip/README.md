# TipCheck starter
Rules-first educational prototype. Not a fraud detector or investment adviser.
## Start
Use Node >=22.12 and Python 3.11 or 3.12 on the team machine.
Backend: cd backend; python -m venv .venv; activate; python -m pip install fastapi uvicorn scikit-learn joblib; python -m uvicorn main:app --reload
Frontend (another terminal): cd frontend; npm ci; npm run dev
Vite proxies /api to port 8000. No Express, database, API key or hosting needed.
## ML
Create backend/dataset.csv with headers id,text,label,language,group_id,source_url,origin,reviewer,split.
Labels: promotion, education, neutral. Training CSV is NOT included: the team must author, review and split it.
Use split=train or test; group paraphrases/translations together. At least three distinct train groups per class are needed for grouped CV; use far more for a meaningful comparison.
python train.py; restart backend. Optional: pip install lightgbm before training. If installation exceeds 15 minutes, keep logistic regression.
Only load model.joblib produced locally by your team. Pickle/joblib from unknown sources can execute code.
## Verification already done
Backend smoke assertions passed and frontend production build succeeded in the preparation environment. This is NOT end-to-end browser testing or model validation. Training mechanics tested separately using artificial data, not a benchmark.
## Known limits
Short keyword patterns, simple sentence-level warning suppression, narrow English/Hindi vocabulary. Mixed warning and promotion in one sentence may hide a red flag. 'None detected' never means safe. ML confidence is uncalibrated. No URL is visited, registration verified or claim fact-checked.
No messages intentionally stored; do not add request-body logging or third-party analytics. Use fictional data in demo. Browser memory contains the entered text; reset it after the demo.
## Licenses
Keep third-party notices and declare dependencies in the submission. Check hackathon terms before selecting a license for the team's own code; organiser FAQ states submitted IP vests in NSDL.
